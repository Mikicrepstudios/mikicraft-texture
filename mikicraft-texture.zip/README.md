If you want to update zip file run `pack.sh`, **DONT RUN ANY ELSE SCRIPTS**


Made for Minecraft java edition 1.16.5, will work in other versions
