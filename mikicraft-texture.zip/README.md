# DO NOT RUN SCRIPT
I made script for myself to make it easier to modify, you are supposed to just move root folder to `.minecraft/resourcepacks`

If you want to update zip file run `pack.sh`


Made for Minecraft java edition 1.16.5, will work in other versions
