sudo cp . ~/.minecraft/resourcepacks/mikicraft-texture -r

