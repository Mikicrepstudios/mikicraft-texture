sudo rm /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture -rf
sudo cp . /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture -r

sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*/*/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*/*/*/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*/*/*/*/*
sudo chmod 777 /home/mikicrep/.minecraft/resourcepacks/mikicraft-texture/*/*/*/*/*/*/*
