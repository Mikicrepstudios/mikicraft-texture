rm mikicraft-texture.zip
7z a mikicraft-texture.zip *
